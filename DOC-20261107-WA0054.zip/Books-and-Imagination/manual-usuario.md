# Manual de usuario
## Bienvenido a Books and Imagination
Esta librería es una demostración. No cobra dinero y no realiza envíos físicos. Tu cuenta, tus reseñas y tu carrito se guardan únicamente en tu navegador, por eso no aparecen si entras desde otro dispositivo. Los títulos y autores corresponden a obras publicadas; los precios, las calificaciones y las primeras reseñas se crearon para mostrar la experiencia, y sus nombres son ejemplos ficticios.

## 1. Abrir y navegar
Abre la página con conexión a Internet. En la parte superior encontrarás Inicio, Clásicos, Populares, Categorías, Opiniones, Contacto, el acceso a tu cuenta y el Carrito. Al tocar una opción, la página se desplaza hasta esa sección. En un teléfono, toca el símbolo de tres líneas para ver las opciones. La bolsa y su contador siguen disponibles arriba.

La primera pantalla tiene dos accesos: Explorar clásicos y Descubrir populares. La flecha flotante permite regresar arriba cuando hayas bajado por la página.

## 2. Encontrar una lectura
Escribe un título, parte del título o el nombre de un autor en el buscador. No es necesario escribir las tildes. Los resultados cambian a medida que escribes y se aplican a las tres colecciones. Borra el texto para recuperar el catálogo.

Junto al buscador puedes seleccionar Recomendados, Precio: menor a mayor, Precio: mayor a menor o Mejor calificación. El orden cambia en todas las colecciones. Las primeras tarjetas son una selección; Descubrir más muestra diez adicionales y Ver todos despliega la colección completa. Si no aparecen resultados, cambia las palabras o borra la búsqueda.

## 3. Explorar categorías
En Categorías, toca Ficción, Fantasía, Romance, Misterio, Ciencia ficción, Historia, Terror, Aventura, Desarrollo personal o Poesía y teatro. El botón seleccionado aparece oscuro. Cada categoría contiene veinte libros. Un libro aparece también en su colección de clásicos o populares; sigue siendo el mismo producto.

## 4. Leer detalles y reseñas
Toca la portada o el título. Se abrirá una ventana con autor, sinopsis, precio, calificación y entre una y cinco reseñas. Las reseñas de ejemplo son ficticias y pueden ser favorables, regulares o negativas. Al final de la ventana puedes escribir tu propia reseña (sección 7). Cierra la ventana con la equis o la tecla Escape.

Algunas portadas provienen de Open Library y pueden estar en otro idioma. Si no hay una portada disponible o falla la conexión, aparece una cubierta decorativa con título y autor. El corazón guarda un favorito durante esa visita; no es una lista permanente.

## 5. Usar el carrito
Toca la bolsa con un signo más en una tarjeta o Añadir al carrito dentro de los detalles. Una notificación confirma la acción. Si añades el mismo libro otra vez, aumentan sus unidades, no se crean productos repetidos.

Abre Carrito desde la barra superior. Usa + para aumentar, − para disminuir y la papelera para quitar un producto. Al llegar a cero unidades, el producto desaparece. El contador muestra todas las unidades y el total se actualiza al instante en pesos colombianos. Existe un límite técnico de 999 unidades por título.

El carrito se conserva en ese navegador mediante almacenamiento local. No se comparte entre dispositivos y puede desaparecer al borrar los datos de navegación. Si el navegador bloquea ese almacenamiento, verás una notificación.

## 6. Crear una cuenta e iniciar sesión
Toca el símbolo de persona en la parte superior. También se abrirá esta ventana cuando intentes confirmar una compra o escribir una reseña sin haber iniciado sesión; al terminar, continúas justo donde estabas.

Para registrarte, escribe nombre y apellido, un correo válido y una contraseña de al menos ocho caracteres, y repítela. La cuenta queda guardada en tu navegador, así que la próxima vez solo tienes que iniciar sesión con el mismo correo y la misma contraseña. Si el correo ya tiene una cuenta, la página te lo avisa; si la contraseña es incorrecta o el correo no existe, también.

Cuando hay una sesión abierta, arriba aparece tu nombre. Al tocarlo se muestra tu correo y la opción Cerrar sesión. Puedes crear una segunda cuenta con otro correo y alternar entre las dos cerrando una sesión e iniciando la otra. La contraseña se guarda cifrada y no se puede ver, pero no uses una que tengas en otros servicios: esta página no tiene un servidor que proteja las cuentas.

## 7. Escribir reseñas
Reseña de un libro: abre los detalles del libro y baja hasta el final. Si no has iniciado sesión, verás un botón para hacerlo. Con la sesión abierta, elige de una a cinco estrellas, escribe al menos diez caracteres y toca Publicar reseña. Tu reseña aparece primero con la etiqueta Tu reseña y la calificación del libro se recalcula. Solo puedes tener una reseña por libro: si escribes otra, reemplaza la anterior.

Reseña de la página: baja hasta Cuéntanos tu experiencia, cerca del final. Funciona igual: requiere sesión, estrellas y un comentario. A la derecha se muestran las reseñas publicadas, las más recientes primero.

Como todo se guarda en tu navegador, otras personas no verán tus reseñas desde sus dispositivos.

## 8. Confirmar la compra
Con productos en el carrito, toca Confirmar compra.

Si no has iniciado sesión, primero se abre la ventana de inicio de sesión y la pantalla de datos no aparece hasta que lo hagas. Si ya tienes una sesión, se abre directamente la pantalla Datos de tu compra, donde debes completar dos cosas:

1. Método de pago. Con Nequi, escribe el celular de tu cuenta (10 dígitos que empiecen por 3). Con tarjeta, escribe número, nombre del titular, vencimiento en formato MM/AA y código de seguridad.
2. Dirección de entrega. Nombre de quien recibe, celular de contacto, departamento, ciudad y dirección. Las indicaciones adicionales son opcionales.

Si falta algo o tiene un formato incorrecto, un aviso rojo te dice qué corregir. Al confirmar aparece el resumen con número de pedido, libros, total, forma de pago (solo los últimos cuatro dígitos) y dirección, y el carrito se vacía.

Es una demostración: no se realiza ningún cobro y los datos de pago y dirección no se guardan. El correo de confirmación solo se envía si la persona responsable configuró EmailJS; si no, la ventana lo indica. Revisa también la carpeta de correo no deseado.

## 9. Contacto y privacidad
Para escribirnos usa booksandimagination.store@gmail.com, que aparece en la sección Contacto. Al final de la página encontrarás un resumen de privacidad y el botón Política de privacidad, que explica qué datos se usan, dónde se guardan, cómo se tratan los datos de pago y entrega y qué derechos tienes según la Ley 1581 de 2012 de Colombia.
