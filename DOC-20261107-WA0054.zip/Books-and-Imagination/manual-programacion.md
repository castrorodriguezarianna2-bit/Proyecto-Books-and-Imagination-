# Manual de programación
## 1. Qué se entrega y por qué
El proyecto independiente está escrito con HTML5, CSS3 y JavaScript puro. Bootstrap 5, Bootstrap Icons, Google Fonts y EmailJS se cargan por CDN: el navegador los descarga desde sus distribuidores. No necesita instalar paquetes ni compilar código. Se usa Bootstrap para ventanas, navegación móvil y notificaciones; el aspecto propio se define en la hoja de estilos para evitar una plantilla genérica.

En Lovable, la página principal conserva el contenedor obligatorio de TanStack Start y muestra esta misma página independiente. El proyecto descargado no depende de React ni TanStack. Los cuatro archivos de código están completos y no contienen comentarios.

## 2. Estructura de carpetas
```text
Books-and-Imagination/
  index.html
  css/
    estilos.css
  js/
    datos.js
    app.js
  images/
    estanque.jpg
    logo.svg
  manual-usuario.md
  manual-programacion.md
```

`index.html` contiene las secciones, los enlaces internos, las ventanas, el formulario y las referencias a las bibliotecas. Sus identificadores conectan los botones con las funciones de JavaScript.

`css/estilos.css` contiene los colores, las fuentes, los tamaños, las distribuciones, los efectos y los ajustes para pantallas pequeñas. Centralizar la apariencia permite cambiarla sin modificar cada tarjeta.

`js/datos.js` contiene un arreglo llamado `libros` con 200 objetos literales: 116 clásicos y 84 populares, distribuidos entre diez categorías de veinte títulos. No genera títulos repetidos para alcanzar las cantidades.

`js/app.js` contiene el estado de la visita, la creación de tarjetas, las búsquedas, las reseñas, el carrito, las cuentas, el pago y el envío de correo. Se carga después de datos.js porque necesita que el arreglo ya exista.

`images/estanque.jpg` es la imagen local del estanque, aclarada y recortada para que combine con la paleta clara. Se incluye para que la primera pantalla no dependa de una imagen externa cambiante.

`images/logo.svg` es el logo: un gato que asoma sobre un libro, dibujado con formas simples. Al ser un SVG se ve nítido en cualquier tamaño y pesa muy poco. Se usa en el encabezado, en el pie y como icono de la pestaña del navegador.

## 3. Abrir el proyecto
Descomprime todo conservando las carpetas. Puedes abrir index.html para inspeccionar la página; para probar EmailJS y el almacenamiento de manera fiable, sirve la carpeta mediante un servidor local o publícala en un alojamiento estático con HTTPS. Si tienes Python instalado, abre una terminal en la carpeta y ejecuta `python3 -m http.server 8000`; visita `http://localhost:8000`.

Necesitas Internet para las fuentes, Bootstrap, los iconos, las portadas y EmailJS. No es una aplicación sin conexión. La carpeta completa puede publicarse en un alojamiento estático; no necesita un servidor privado.

## 4. Cómo leer un objeto libro
Cada libro tiene:
- `id`: número único que vincula detalles y carrito.
- `titulo` y `autor`: textos visibles y campos de búsqueda.
- `categoria`: uno de los diez géneros. La lista de botones se obtiene del arreglo.
- `catalogo`: `clasicos` o `populares`.
- `precio`: un número entero en COP, sin signos ni separadores; se formatea al mostrarlo.
- `sinopsis`: descripción breve específica de esa obra.
- `calificacion`: un número entre 1 y 5, independiente de los ejemplos de reseñas.
- `portada`: URL bibliográfica de Open Library o cadena vacía cuando no se obtuvo una cubierta.
- `resenas`: arreglo de entre una y cinco entradas con nombre, comentario y calificacion.

Los precios y las calificaciones son datos de demostración, no precios editoriales comprobados. Los comentarios y los nombres son ficticios; la reseña positiva de Jhoan Manrique se incluyó por requisito, sin atribuirle un testimonio real.

Se localizaron URLs bibliográficas para 160 títulos; los 40 restantes utilizan la cubierta decorativa. No todas las ediciones están en español ni todas las URLs han sido verificadas visualmente. Antes de publicar un catálogo real, revisa que cada imagen corresponda exactamente al título y a la edición vendida, y comprueba los permisos de uso.

## 5. Agregar o editar un libro
Abre datos.js y localiza un objeto por su título. Cambia sus campos conservando las comillas en textos y sin ponerlas alrededor del precio o el identificador. Para añadir un título, copia un objeto completo, coloca una coma entre objetos y asigna un id que no exista. Escoge una categoría existente para conservar los diez filtros. Si añades otra categoría, aparecerá automáticamente; actualiza los textos que anuncian diez géneros y revisa los requisitos de cantidad.

Mantén entre una y cinco reseñas por libro y calificaciones entre 1 y 5. Una URL vacía no rompe la tarjeta: activa el respaldo. Para una portada por ISBN utiliza `https://covers.openlibrary.org/b/isbn/ISBN-L.jpg?default=false`, sustituyendo ISBN por el de una edición real. `default=false` permite detectar la ausencia de imagen en lugar de aceptar una cubierta vacía.

No cambies el id de un libro que ya puede estar en carritos: el almacenamiento conserva ese identificador. Una eliminación del catálogo se limpia al recargar, para no dejar referencias inexistentes.

## 6. Búsqueda, orden y aparición
`normalizar` elimina las tildes y convierte el texto a minúsculas. Así, una búsqueda como Garcia encuentra García. `librosFiltrados` combina catálogo o categoría con título y autor. `ordenar` trabaja sobre una copia: no modifica el inventario original al cambiar el orden.

Cada colección empieza con cinco libros, añade diez con el botón correspondiente y permite expandirse completamente. Esto evita descargar doscientas portadas al abrir la página. Las imágenes utilizan carga diferida. Un observador de intersección revela las tarjetas al entrar en pantalla, sin consultar continuamente posiciones durante el desplazamiento. Si el visitante solicita movimiento reducido en su dispositivo, las animaciones se desactivan.

`escapar` transforma caracteres especiales antes de incluir textos en contenido HTML dinámico. Así, un título con símbolos no altera la estructura y el nombre o correo del formulario no se interpretan como etiquetas ejecutables.

## 7. Detalles, portadas y notificaciones
`mostrarLibro` busca el id en el arreglo y crea la ventana de Bootstrap. `estrellas` representa estrellas llenas, medias y vacías y añade una descripción accesible. `gestionarPortadas` detecta errores y cubiertas minúsculas; elimina la imagen fallida para descubrir el respaldo decorativo.

`avisar` actualiza una notificación de Bootstrap y la muestra durante unos segundos. El código usa un único manejador de clics para botones creados posteriormente; esto evita tener que volver a conectar cada tarjeta al cambiar filtros.

## 8. Carrito y persistencia
El carrito contiene solamente `{ id, cantidad }`. Los títulos y los precios se consultan en el catálogo para evitar mantener dos copias que podrían divergir.

`agregarLibro` crea un producto o aumenta su cantidad. `cambiarCantidad` aplica +1 o −1 y elimina cantidades iguales a cero. La papelera elimina directamente. `totalCarrito` multiplica cada precio por sus unidades y suma los resultados. `mostrarCarrito` vuelve a dibujar filas, contador y total tras cada modificación.

`guardarAlmacenamiento` utiliza localStorage, un espacio del navegador que persiste al cerrar la pestaña. `leerAlmacenamiento` contempla contenido ausente o JSON inválido. Al iniciar, se descartan ids desconocidos y cantidades incorrectas. Las cantidades se limitan a 999 para evitar entradas descontroladas.

Este almacenamiento no sincroniza dispositivos, no protege información comercial y puede ser modificado por el usuario. Por eso no debe usarse como fuente de precios o pedidos en una tienda real.

## 9. Cuentas y sesión
Las cuentas viven en localStorage bajo la clave `books-imagination-cuentas`, como un arreglo de objetos con nombre, correo, `sal` y `clave`. Nunca se guarda la contraseña: se guarda su huella. `calcularHuella` mezcla una sal aleatoria con la contraseña y aplica SHA-256 con la API `crypto.subtle` del navegador. La sal evita que dos personas con la misma contraseña tengan la misma huella, y la huella impide leer la contraseña original desde el almacenamiento. `crypto.subtle` solo funciona en páginas con HTTPS o en localhost; Render ofrece HTTPS, por eso funciona allí.

`enviarSesion` tiene dos caminos. En el registro verifica que el correo no exista, crea la cuenta y abre la sesión. En el inicio busca la cuenta por correo, recalcula la huella con la sal guardada y la compara. Si no coincide, informa el error y no abre sesión. La sesión activa se guarda como el correo en `books-imagination-sesion`; al cargar la página, `app.js` busca esa cuenta y, si ya no existe, descarta la sesión. Como las cuentas persisten, se pueden crear dos o más y alternar entre ellas con `cerrarSesion`.

`abrirSesion` recibe una acción pendiente (`compra`, `resena-libro` o `resena-sitio`). Cuando el inicio de sesión termina y la ventana se cierra, `ejecutarAccion` la retoma: abre la pantalla de pago, reabre el libro con su formulario o enfoca el cuadro de la reseña. Se espera a que la ventana termine de cerrarse para no apilar ventanas de Bootstrap.

**Límite importante:** todo está en el navegador de cada visitante. Una cuenta creada en un computador no existe en otro, y el usuario puede editar su propio almacenamiento. Para cuentas compartidas entre dispositivos se necesita un servidor con base de datos y autenticación; una web estática en Render no puede ofrecerlo por sí sola.

## 10. Reseñas
Las reseñas de libros se guardan en `books-imagination-resenas-libros`, un objeto cuya clave es el id del libro y cuyo valor es la lista de reseñas de usuarios. Las reseñas de la página están en `books-imagination-resenas-sitio`, un arreglo. Al cargar, `resenaValida` descarta cualquier entrada con formato incorrecto, porque el almacenamiento puede haber sido modificado.

`selectorEstrellas` dibuja cinco botones de opción (radio) en orden inverso y los muestra invertidos con CSS. Gracias a ese orden, el selector de CSS `~` pinta de rosa la estrella elegida y todas las de su izquierda sin usar JavaScript. Además, al ser radios reales, funcionan con teclado y lectores de pantalla.

`publicarResenaLibro` y `publicarResenaSitio` validan estrella y longitud mínima con `validarResena`, guardan una reseña por correo (si ya existe, la reemplazan) y vuelven a dibujar la lista. `calificacionDe` recalcula el promedio del libro mezclando la calificación base con las reseñas de usuarios, y por eso las tarjetas del catálogo se redibujan tras publicar. Todo texto escrito por el usuario pasa por `escapar` antes de mostrarse.

## 11. Flujo de compra y datos de pago
`confirmarCompra` comprueba que haya productos. Sin sesión, llama a `abrirSesion` con la acción `compra`, y la pantalla de datos no se muestra hasta iniciar sesión. Con sesión, `abrirPago` muestra el total y abre la ventana Datos de tu compra.

`leerPago` reúne los campos y `validarPago` los revisa: celular Nequi de diez dígitos que empiece por 3; para tarjeta, quince o dieciséis dígitos, titular, vencimiento válido que no esté vencido y código de tres o cuatro dígitos; y la dirección completa. `formatearCampo` deja solo números, agrupa la tarjeta de cuatro en cuatro y pone la barra en MM/AA mientras se escribe. No se aplica el algoritmo de Luhn para que las pruebas con números inventados no se rechacen.

`enviarPago` construye un objeto `entrega` que solo contiene los últimos cuatro dígitos del medio de pago, el receptor y la dirección. Después reinicia el formulario, de modo que el número completo de la tarjeta no queda en la página, y espera a que la ventana se cierre antes de llamar a `completarCompra`. Esta función copia el pedido, bloquea cambios del carrito mientras confirma, muestra el resumen con número de pedido, llama a `enviarCorreo` y vacía el carrito. Los datos de pago y dirección nunca se escriben en localStorage.

El éxito visible corresponde a la demostración: no hay pasarela de pagos ni cobro real. Para cobrar de verdad se necesita un proveedor de pagos (por ejemplo, uno que ofrezca Nequi y tarjetas en Colombia) y un servidor que procese los pedidos; el navegador nunca debe manejar por sí solo los datos de cobro.

## 12. Configurar EmailJS paso a paso
1. Crea una cuenta en EmailJS y revisa los límites vigentes de su plan gratuito. No se garantizan cuotas ilimitadas.
2. En Email Services, añade el servicio de correo que utilizarás y completa la autorización que solicita EmailJS. Copia su Service ID.
3. En Email Templates, crea una plantilla para el resumen de compra. En el destinatario escribe `{{to_email}}`. En el nombre del destinatario utiliza `{{to_name}}`.
4. Establece un asunto como `Gracias por tu compra simulada en Books and Imagination`.
5. El contenido debe ser de **texto plano**, sin imágenes ni HTML: utiliza `{{message}}`. Selecciona el formato de texto plano si tu editor lo ofrece. El código manda agradecimiento, líneas del pedido y total en esa variable. No añadas promociones.
6. Guarda la plantilla y copia su Template ID.
7. En Account o API Keys, copia la Public Key de EmailJS. No copies una clave privada o contraseña del correo.
8. Abre js/app.js. Su primer objeto es `configuracionCorreo`. Sustituye las cadenas vacías de `clavePublica`, `servicio` y `plantilla` por la Public Key, el Service ID y el Template ID, respectivamente. No cambies sus nombres ni la estructura.
9. En la configuración de seguridad de EmailJS, limita los dominios autorizados al dominio real de tu web y al origen local si vas a probar allí. Estas claves públicas son visibles desde el navegador; no equivalen a un secreto de servidor.
10. Prueba una compra con tu propio correo y productos en el carrito. Busca el resumen recibido y revisa correo no deseado. No consideres verificado el envío solo porque aparece el mensaje de compra.
11. Si falla, revisa IDs, destinatario, dominios permitidos, conexión y cuota. La web informa del fallo y no reintenta en bucle, para evitar mensajes duplicados.

EmailJS se invoca solo una vez para el destinatario de esa compra. El código no envía listas, campañas ni promociones. Una solución exclusivamente del lado del cliente no puede impedir toda manipulación o abuso: configura las restricciones del proveedor y no utilices esta demostración como comercio real sin controles adicionales. El envío real no fue probado porque no se proporcionaron claves.

## 13. Cambiar paleta y tipografías
Al principio de estilos.css están las variables principales en `:root`. La paleta es: `--laguna` (#2D3A47, azul noche para textos, botones y zonas oscuras), `--crema` (#FFF7E6, fondo), `--petalo` (#F7C8D3), `--palo-rosa` (#B46A72, acento), `--salvia` (#A8B58A) y `--cielo` (#A9B7C6). Se eligió una base clara y cálida, con un azul noche que aporta contraste para leer, porque los fondos oscuros y verdes cansaban en la primera pantalla. Los tonos auxiliares (`--rosa-suave`, `--rosa-texto`, `--salvia-texto`, `--cielo-suave`, `--borde`, `--texto-suave`) son versiones más claras u oscuras de esos colores: se crearon para que el texto pequeño tenga suficiente contraste.

Para cambiar un color, modifica su variable. El resto de la hoja usa las variables, por lo que el cambio se refleja en toda la página. Si cambias un color base, revisa también su tono auxiliar. El logo (`images/logo.svg`) usa los mismos colores escritos directamente en el archivo; si cambias la paleta, edita esos valores.

Las fuentes son Lora para títulos y DM Sans para texto. Se cargan en el encabezado HTML y se referencian con `--fuente-titulo` y `--fuente-texto`. Si cambias las fuentes, actualiza tanto el enlace de Google Fonts como esas variables.

En la primera pantalla, la imagen del estanque se funde con el fondo crema mediante una máscara de degradado en CSS (`mask-image`), de modo que el texto siempre se lee sobre un color liso.

## 14. Antes de convertirla en una librería real
Verifica portadas, precios, disponibilidad y derechos de las imágenes; sustituye las reseñas de ejemplo (incluidas las tres de la sección Opiniones) por testimonios reales con permiso. Añade autenticación y base de datos en un servidor, una pasarela de pagos y pedidos verificados, y revisa la política de privacidad con asesoría legal. No quites los avisos de demostración mientras no exista una tienda real. El proyecto no contiene comentarios en HTML, CSS o JavaScript; las explicaciones se mantienen en estos manuales para que el código permanezca limpio.

